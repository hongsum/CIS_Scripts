#output console stats to text file
if ! [ -f OutputStats.log ] ; then 
	rm -f OutputStats.log
fi
exec > >(tee -a OutputStats.log) 2>&1

#Global Variables
pass="Pass"
fail="Fail"
na="Not Applicable"
invalid="Invalid Input"
executed="Command Executed"

echo "Starting CIS Red Hat Enterprise Linux 7 Benchmark V1.0.0 Hardening Check...."
echo ""

#To generate all the function numbers by loop
generateNumber()
{
	value=200
	#if number.txt not found, create an empty txtfile named number.txt
	if ! [ -f number.txt ] ; then 
	touch number.txt
	fi

	for (( i=1; i<=$value; i++ ))
	do
	   echo CIS$i >> number.txt
	done
}


#1.1.1 Create Separate Partition for /tmp (Scored)
#If there is no output then the system is not configured as recommended
CIS1()
{
	logMsg="1.1.1 Create Separate Partition for /tmp (Scored)"

	if [[ `grep "[[:space:]]/tmp[[:space:]]" /etc/fstab` ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
	
}

#1.1.2 Set nodev option for /tmp Partition (Scored)
#If either command emits no output then the system is not configured as recommended
CIS2()
{
	logMsg="1.1.2 Set nodev option for /tmp Partition (Scored)"
	
	if [[ `grep "[[:space:]]/tmp[[:space:]]" /etc/fstab` ]] && [[ `mount | grep "[[:space:]]/tmp[[:space:]]" | grep nodev` ]]
	then	
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#1.1.3 Set nosuid option for /tmp Partition (Scored)
#If either command emits no output then the system is not configured as recommended
CIS3()
{
	logMsg="1.1.3 Set nosuid option for /tmp Partition (Scored)"
	
	if [[ `grep "[[:space:]]/tmp[[:space:]]" /etc/fstab | grep nosuid` ]] && [[ `mount | grep "[[:space:]]/tmp[[:space:]]" | grep nosuid` ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""	
}

#1.1.4 Set noexec option for /tmp Partition (Scored)
#If either command emits no output then the system is not configured as recommended.
CIS4()
{
	logMsg="1.1.4 Set noexec option for /tmp Partition (Scored)"
	if [[ `grep "[[:space:]]/tmp[[:space:]]" /etc/fstab | grep noexec` ]] && [[ `mount | grep "[[:space:]]/tmp[[:space:]]" | grep noexec` ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#1.1.5 Create Separate Partition for /var (Scored)
CIS5()
{
	logMsg="1.1.5 Create Separate Partition for /var (Scored)"
	
	if [[ `grep "[[:space:]]/var[[:space:]]" /etc/fstab` ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	
	fi
	echo ""
}

#1.1.6 Bind Mount the /var/tmp directory to /tmp (Scored)
CIS6()
{
	logMsg="1.1.6 Bind Mount the /var/tmp directory to /tmp (Scored)"
	
	if [[ `grep -e "^/tmp[[:space:]]" /etc/fstab | grep /var/tmp` ]] && [[ `mount | grep -e "^/tmp[[:space:]]" | grep /var/tmp` ]]
	then	
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#1.1.7 Create Separate Partition for /var/log (Scored)
CIS7()
{
	logMsg="1.1.7 Create Separate Partition for /var/log (Scored)"
	
	if [[ `grep "[[:space:]]/var/log[[:space:]]" /etc/fstab` ]]
	then	
		echo $logMsg: $pass
	else	
		echo $logMsg: $fail
	fi	
	echo ""
}

#1.1.8 Create Separate Partition for /var/log/audit (Scored)
CIS8()
{
	logMsg="1.1.8 Create Separate Partition for /var/log/audit (Scored)"
	
	if [[ `grep "[[:space:]]/var/log/audit[[:space:]]" /etc/fstab` ]]
	then	
		echo $logMsg: $pass
	else	
		echo $logMsg: $fail
	fi	
	echo ""
}

#1.1.9 Create Separate Partition for /home (Scored)
CIS9()
{
	logMsg="1.1.9 Create Separate Partition for /home (Scored)"
	if [[ `grep "[[:space:]]/home[[:space:]]" /etc/fstab` ]]
	then
		echo $logMsg: $pass
	else	
		echo $logMsg: $fail
	fi	
	echo ""
}

#1.1.10 Add nodev Option to /home (Scored)
CIS10()
{
	logMsg="1.1.10 Add nodev Option to /home (Scored)"
	if [[ `grep "[[:space:]]/home[[:space:]]" /etc/fstab` ]] && [[ `mount | grep /home` ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail 
	fi	
	echo ""
}

#1.1.11 Add nodev Option to Removable Media Partitions (Not Scored)
#1.1.12 Add noexec Option to Removable Media Partitions (Not Scored)
#1.1.13 Add nosuid Option to Removable Media Partitions (Not Scored)
CIS11()
{
	logMsg1="1.1.11 Add nodev Option to Removable Media Partitions (Not Scored)"
	logMsg2="1.1.12 Add noexec Option to Removable Media Partitions (Not Scored)"
	logMsg3="1.1.13 Add nosuid Option to Removable Media Partitions (Not Scored)"
	
	read -r -p 'Is there any removable media partition in this server[Y/N]?' reply
	case $reply in
	y|Y)
		echo ""
		echo $logMsg1: $fail
		echo $logMsg2: $fail
		echo $logMsg3: $fail
		;;
		
	n|N)
		echo ""
		echo $logMsg1: $na
		echo $logMsg2: $na
		echo $logMsg3: $na
		;;

	*)
		echo ""
		echo $invalid
        ;;
	esac	
	echo ""
}


#1.1.14 Add nodev Option to /dev/shm Partition (Scored)
#If either command emits no output then the system is not configured as recommended.
CIS12()
{
	logMsg="1.1.14 Add nodev Option to /dev/shm Partition (Scored)"
	if [[ `grep /dev/shm /etc/fstab | grep nodev` ]] && [[ `mount | grep /dev/shm | grep nodev` ]] 
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#1.1.15 Add nosuid Option to /dev/shm Partition (Scored)
#If either command emits no output then the system is not configured as recommended.
CIS13()
{
	logMsg="1.1.15 Add nosuid Option to /dev/shm Partition (Scored)"
	if [[ `grep /dev/shm /etc/fstab | grep nosuid` ]] && [[ `mount | grep /dev/shm | grep nosuid` ]] 
	then	
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#1.1.16 Add noexec Option to /dev/shm Partition (Scored)
#If either command emits no output then the system is not configured as recommended.
CIS14()
{
	logMsg="1.1.16 Add noexec Option to /dev/shm Partition (Scored)"
	if [[ `grep /dev/shm /etc/fstab | grep noexec` ]] && [[ `mount | grep /dev/shm | grep noexec` ]] 
	then 
		echo $logMsg: $pass
	else	
		echo $logMsg: $fail
	fi	
	echo ""
}

#1.1.17 Set Sticky Bit on All World-Writable Directories (Scored)
CIS15()
{
	logMsg="1.1.17 Set Sticky Bit on All World-Writable Directories (Scored)"
	echo $logMsg : $executed
	df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -a ! -perm -1000 \) 2>/dev/null
	
	echo ""
}

#1.1.18 Disable Mounting of cramfs Filesystems (Not Scored)
CIS16()
{
	logMsg="1.1.18 Disable Mounting of cramfs Filesystems (Not Scored)"
	
	if [[ `/sbin/modprobe -n -v cramfs` == *"install /bin/true"* ]] && [[ `/sbin/lsmod | grep cramfs` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	

	echo ""
}

#1.1.19 Disable Mounting of freevxfs Filesystems (Not Scored)
CIS17()
{
	logMsg="1.1.19 Disable Mounting of freevxfs Filesystems (Not Scored)"
	
	if [[ `/sbin/modprobe -n -v freevxfs` == *"install /bin/true"* ]] && [[ `/sbin/lsmod | grep freevxfs` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	
	echo ""
}


#1.1.20 Disable Mounting of jffs2 Filesystems (Not Scored)
CIS18()
{
	logMsg="1.1.20 Disable Mounting of jffs2 Filesystems (Not Scored)"
	
	if [[ `/sbin/modprobe -n -v jffs2` == *"install /bin/true"* ]] && [[ `/sbin/lsmod | grep jffs2` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	
	echo ""
}

#1.1.21 Disable Mounting of hfs Filesystems (Not Scored)
CIS19()
{
	logMsg="1.1.21 Disable Mounting of hfs Filesystems (Not Scored)"
	
	if [[ `/sbin/modprobe -n -v hfs` == *"install /bin/true"* ]] && [[ `/sbin/lsmod | grep hfs` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	
	echo ""
}

#1.1.22 Disable Mounting of hfsplus Filesystems (Not Scored)
CIS20()
{
	logMsg="1.1.22 Disable Mounting of hfsplus Filesystems (Not Scored)"
	
	if [[ `/sbin/modprobe -n -v hfsplus` == *"install /bin/true"* ]] && [[ `/sbin/lsmod | grep hfsplus` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	
	echo ""
}

#1.1.23 Disable Mounting of squashfs Filesystems (Not Scored)
CIS21()
{
	logMsg="1.1.23 Disable Mounting of squashfs Filesystems (Not Scored)"
	if [[ `/sbin/modprobe -n -v squashfs` == *"install /bin/true"* ]] && [[ `/sbin/lsmod | grep squashfs` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	
	echo ""	
}

#1.1.24 Disable Mounting of udf Filesystems (Not Scored)
CIS22()
{
	logMsg="1.1.24 Disable Mounting of udf Filesystems (Not Scored)"
	if [[ `/sbin/modprobe -n -v udf` == *"install /bin/true"* ]] && [[ `/sbin/lsmod | grep udf` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	
	echo ""
}

#1.2.1 Configure Connection to the RHN RPM Repositories (Not Scored)
CIS23()
{
	logMsg="1.2.1 Configure Connection to the RHN RPM Repositories (Not Scored)"
	yum check-update
	echo $logMsg: $executed 
	echo "Verify to check if the system is registered"
	echo ""
}

#1.2.2 Verify Red Hat GPG Key is Installed (Scored)
CIS24()
{
        logMsg="1.2.2 Verify Red Hat GPG Key is Installed (Scored)"
		rpm -q --queryformat "%{SUMMARY}\n" gpg-pubkey
        answer=`rpm -q --queryformat "%{SUMMARY}\n" gpg-pubkey`

        if [[ `echo $answer | grep "not"` ]]
        then
                echo $logMsg: $fail
        else
                echo $logMsg: $pass
        fi
		echo ""
}

#1.2.3 Verify that gpgcheck is Globally Activated (Scored)
CIS25()
{
	logMsg="1.2.3 Verify that gpgcheck is Globally Activated (Scored)"
	if [[ `grep gpgcheck /etc/yum.conf` == "gpgcheck=1" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#1.2.4 Disable the rhnsd Daemon (Not Scored)
CIS26()
{
	logMsg="1.2.4 Disable the rhnsd Daemon (Not Scored)"
	answer=`systemctl is-enabled rhnsd`
	if [[ `echo $answer | grep "disabled"` ]]
	then 
		echo $logMsg: $pass
	else
		echo $logMsg: $fail 
	fi
	echo ""
}

#1.2.5 Obtain Software Package Updates with yum (Not Scored)
CIS27()
{
	logMsg="1.2.5 Obtain Software Package Updates with yum (Not Scored)"
	yum check-update
	echo $logMsg: $executed 
	echo "Determine if there are any packages that needs to be updated"
	echo ""
}


#1.2.6 Verify Package Integrity Using RPM (Not Scored)
CIS28()
{
	logMsg="1.2.6 Verify Package Integrity Using RPM (Not Scored)"
	rpm -qVa | awk '$2 != "c" { print $0}'
	output=`rpm -qVa | awk '$2 != "c" { print $0}'`

	if [[ $output ]]
	then	
		echo "If any output shows up, you may have an integrity issue with that package"
		echo $logMsg: $fail
		
	else	
		echo $logMsg: $pass
	fi
	echo ""
}

#1.3 Advanced Intrusion Detection Environment (AIDE)
#1.3.1 Install AIDE (Scored)
CIS29()
{
	logMsg="1.3.1 Install AIDE (Scored)"
	answer=`rpm -q aide`

	if [[ `echo $answer | grep "not"` ]]
	then
			echo $answer
			echo $logMsg: $fail
	else
			echo $logMsg: $pass
	fi
	echo ""
}

#1.4 Configure SELinux
#1.4.1 Enable SELinux in /etc/grub.conf (Scored)
CIS30()
{
	logMsg="1.4.1 Enable SELinux in /etc/grub.conf (Scored)"
	if [[ `grep selinux=0 /etc/grub.conf` == "" ]] && [[ `grep enforcing=0 /etc/grub.conf` == "" ]] 
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#1.4.2 Set the SELinux State (Scored)
#SELinux status: enabled 
#Current mode: enforcing 
#Mode from config file: enforcing 
#Policy from config file: targeted
CIS31()
{
	logMsg="1.4.2 Set the SELinux State (Scored)"
	
	if [[ `grep SELINUX=enforcing /etc/selinux/config` == "SELINUX=enforcing" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#1.4.3 Set the SELinux Policy (Scored)
# /usr/sbin/sestatus 
#SELinux status: enabled 
#Current mode: enforcing 
#Mode from config file: enforcing 
#Policy from config file: targeted
CIS32()
{
	logMsg="1.4.3 Set the SELinux Policy (Scored)"
	if [[ `grep SELINUX=enforcing /etc/selinux/config` == "SELINUXTYPE=targeted" ]]
	then	
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#1.4.4 Remove SETroubleshoot (Scored)
CIS33()
{
	
	logMsg="1.4.4 Remove SETroubleshoot (Scored)"
	rpm -q setroubleshoot
	answer=`rpm -q setroubleshoot`

	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""

}

#1.4.5 Remove MCS Translation Service (mcstrans) (Scored)
CIS34()
{
	logMsg="1.4.5 Remove MCS Translation Service (mcstrans) (Scored)"
	rpm -q mcstrans
	answer=`rpm -q mcstrans`

	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""


}

#1.4.6 Check for Unconfined Daemons (Scored)
#no output produced means its configured properly
CIS35()
{
	logMsg="1.4.6 Check for Unconfined Daemons (Scored)"
	if [[ `ps -eZ | egrep "initrc" | egrep -vw "tr|ps|egrep|bash|awk" | tr ':' ' ' | awk '{ print $NF }'` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#1.5 Secure Boot Settings
#1.5.1 Set User/Group Owner on /boot/grub2/grub.cfg (Scored)
#If the command emits no output then the system is not configured as recommended
CIS36()
{
	logMsg="1.5.1 Set User/Group Owner on /boot/grub2/grub.cfg (Scored)"
	if [[ `stat -L -c "%u %g" /boot/grub2/grub.cfg | egrep "0 0"` == "" ]]
	then
		echo $logMsg: $fail
	else	
		echo $logMsg: $pass
	fi
	echo ""

}

#1.5.2 Set Permissions on /etc/grub.conf (Scored)
#If the command emits no output then the system is not configured as recommended
CIS37()
{
	logMsg="1.5.2 Set Permissions on /etc/grub.conf (Scored)"
	if [[ `stat -L -c "%a" /boot/grub2/grub.cfg | egrep ".00"` == "" ]]
	then
		echo $logMsg: $fail
	else	
		echo $logMsg: $pass
	fi
	echo "" 
}


#1.5.3 Set Boot Loader Password (Scored)
CIS38()
{
	logMsg="1.5.3 Set Boot Loader Password (Scored)"
	echo $logMsg: $executed 	
	grep "^set superusers" /boot/grub2/grub.cfg
	grep "^password" /boot/grub2/grub.cfg 
	
	#command: grep "^set superusers" /boot/grub2/grub.cfg
	#output: set superusers="<user-list>" 
	
	#Command: grep "^password" /boot/grub2/grub.cfg 
	#output: password_pbkdf2 <user> <encrypted password>
	echo ""
}


#1.6 Additional Process Hardening
#1.6.1 Restrict Core Dumps (Scored)
CIS39()
{
	logMsg="1.6.1 Restrict Core Dumps (Scored)"
	if [[ `grep "hard core" /etc/security/limits.conf` == "* hard core 0" ]] && [[ `sysctl fs.suid_dumpable` == "fs.suid_dumpable = 0" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""	
}

#1.6.1 Enable Randomized Virtual Memory Region Placement (Scored)
CIS40()
{
	logMsg="1.6.1 Enable Randomized Virtual Memory Region Placement (Scored)"
	if [[ `sysctl kernel.randomize_va_space` == "kernel.randomize_va_space = 2" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}


#1.7 Use the Latest OS Release (Not Scored)
CIS41()
{
	logMsg="1.7 Use the Latest OS Release (Not Scored)"
	echo $logMsg: $executed 
	cat /etc/redhat-release
}

#2.1.1 Remove telnet-server (Scored)
CIS42()
{
	logMsg="2.1.1 Remove telnet-server (Scored)"
	answer=`rpm -q telnet-server`

	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}

#2.1.2 Remove telnet Clients (Scored)
CIS43()
{
	logMsg="2.1.2 Remove telnet Clients (Scored)"
	answer=`rpm -q telnet`

	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}

#2.1.3 Remove rsh-server (Scored)
CIS44()
{
	logMsg="2.1.3 Remove rsh-server (Scored)"
	answer=`rpm -q rsh-server`
	
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}

#2.1.4 Remove rsh (Scored)
CIS45()
{
	logMsg="2.1.4 Remove rsh (Scored)"
	answer=`rpm -q rsh`
	
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}


#2.1.5 Remove NIS Client (Scored)
CIS46()
{
	logMsg="2.1.5 Remove NIS Client (Scored)"
	answer=`rpm -q ypbind`
	
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}

#2.1.6 Remove NIS Server (Scored)
CIS47()
{
	logMsg="2.1.5 Remove NIS Client (Scored)"
	answer=`rpm -q ypserv`
	
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}

#2.1.7 Remove tftp (Scored)
CIS48()
{
	logMsg="2.1.7 Remove tftp (Scored)"
	answer=`rpm -q tftp`
	
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""

}

#2.1.8 Remove tftp-server (Scored)
CIS49()
{
	logMsg="2.1.8 Remove tftp-server (Scored)"
	answer=`rpm -q tftp-server`
	
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""

}

#2.1.9 Remove talk (Scored)
CIS50()
{
	logMsg="2.1.9 Remove talk (Scored)"
	answer=`rpm -q talk`
	
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}

#2.1.10 Remove talk-server (Scored)
CIS51()
{
	logMsg="2.1.10 Remove talk-server (Scored)"
	answer=`rpm -q talk-server`
	
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}

#2.1.11 Remove xinetd (Scored)
CIS52()
{
	logMsg="2.1.11 Remove xinetd (Scored)"
	answer=`rpm -q xinetd`
	
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}

#2.1.12 Disable chargen-dgram (Scored)
CIS53()
{
	logMsg="2.1.12 Disable chargen-dgram (Scored)"
	if [[ `chkconfig --list chargen-dgram` == *"chargen-dgram: off"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}


#2.1.13 Disable chargen-stream (Scored)
CIS54()
{
	logMsg="2.1.13 Disable chargen-stream (Scored)"
	if [[ `chkconfig --list chargen-stream` == *"chargen-stream: off"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#2.1.14 Disable daytime-dgram (Scored)
CIS55()
{
	logMsg="2.1.14 Disable daytime-dgram (Scored)"
	if [[ `chkconfig --list daytime-dgram` == *"daytime-dgram: off"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""

}

#2.1.15 Disable daytime-stream (Scored)
CIS56()
{
	#2.1.15 Disable daytime-stream (Scored)
	logMsg="2.1.15 Disable daytime-stream (Scored)"
	if [[ `chkconfig --list daytime-stream` == *"daytime-dgram: off"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
} 
	
#2.1.16 Disable echo-dgram (Scored)
CIS57()
{
	
	logMsg="2.1.16 Disable echo-dgram (Scored)"
	echo $logMsg: $executed
	if [[ `chkconfig --list echo-dgram` == *"echo-dgram: off"* ]]
	then 
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
} 

#2.1.17 Disable echo-stream (Scored)
CIS58()
{
	logMsg="2.1.17 Disable echo-stream (Scored)"
	echo $logMsg: $executed
	
	if [[ `chkconfig --list echo-stream` == *"echo-stream: off"* ]]
	then 
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#2.1.18 Disable tcpmux-server (Scored)
CIS59()
{
	logMsg="2.1.18 Disable tcpmux-server (Scored)"
	echo $logMsg: $executed 
	if [[ `chkconfig --list tcpmux-server` == *"tcpmux-server: off"* ]]
	then 
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#3.1 Set Daemon umask (Scored)
CIS60()
{
	logMsg="3.1 Set Daemon umask (Scored)"
	
	if [[ `grep umask /etc/sysconfig/init` == "umask 027" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
		
	echo ""	
}

#3.2 Remove the X Window System (Scored)
CIS61()
{
	logMsg="3.2 Remove the X Window System (Scored)"
	answer=`rpm -q xorg-x11-server-common`
	if [[ `ls -l /usr/lib/systemd/system/default.target | grep graphical.target` == "graphical.target" ]] && [[ `echo $answer | grep "not"` ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	
	echo ""

}

#3.3 Disable Avahi Server (Scored)
CIS62()
{
	logMsg="3.3 Disable Avahi Server (Scored)"
	if [[ `systemctl is-enabled avahi-daemon` == "" ]]
	then	
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	
	echo ""

}

#3.4 Disable Print Server - CUPS (Not Scored)
CIS63()
{
	logMsg="3.4 Disable Print Server - CUPS (Not Scored)"
	if [[ `systemctl is-enabled cups` == "" ]] 
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail 
	fi
	
	echo ""
}

#3.5 Remove DHCP Server (Scored)
CIS64()
{
	logMsg="3.5 Remove DHCP Server (Scored)"
	answer=`rpm -q dhcp`

	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
	
}

#3.6 Configure Network Time Protocol (NTP) (Scored)
CIS65()
{
	logMsg="3.6 Configure Network Time Protocol (NTP) (Scored)"
	
	if [[ `grep "restrict default" /etc/ntp.conf` ]] && [[ `grep "restrict -6 default" /etc/ntp.conf` ]]
	then
		echo $logMsg: $pass 
	else
		echo $logMsg: $fail
	fi	
	echo ""	
}

#3.7 Remove LDAP (Not Scored)
CIS66()
{
	logMsg="3.7 Remove LDAP (Not Scored)"
		
	rpm -q openldap-servers
	answer1=`rpm -q openldap-servers`
	answer2=`rpm -q openldap-clients`

	if [[ `echo $answer1 | grep "not"` ]] && [[ `echo $answer2 | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
		
}

#3.8 Disable NFS and RPC (Not Scored)
CIS67()
{
	logMsg="3.8 Disable NFS and RPC (Not Scored)"
	
	if [[ `systemctl is-enabled nfslock` == "disabled" ]] && [[ `systemctl is-enabled rpcgssd` == "disabled" ]] && [[ `systemctl is-enabled rpcbind` == "disabled" ]] && [[ `systemctl is-enabled rpcidmapd` == "disabled" ]] && [[ `systemctl is-enabled rpcsvcgssd` == "disabled" ]]
	then 
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}


#3.9 Remove DNS Server (Not Scored)
CIS68()
{
	logMsg="3.9 Remove DNS Server (Not Scored)"
	answer=`rpm -q bind`

	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}

#3.10 Remove FTP Server (Not Scored)
CIS69()
{
	logMsg="3.10 Remove FTP Server (Not Scored)"
	answer=`rpm -q vsftpd`
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}

#3.11 Remove HTTP Server (Not Scored)
CIS70()
{
	logMsg="3.11 Remove HTTP Server (Not Scored)"
	answer=`rpm -q httpd`
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}

#3.12 Remove Dovecot (IMAP and POP3 services) (Not Scored)
CIS71()
{
	logMsg="3.12 Remove Dovecot (IMAP and POP3 services) (Not Scored)"
	answer=`rpm -q dovecot`
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}

#3.13 Remove Samba (Not Scored)
CIS72()
{
	logMsg="3.13 Remove Samba (Not Scored)"
	answer=`rpm -q samba`
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""
}

#3.14 Remove HTTP Proxy Server (Not Scored)
CIS73()
{
	logMsg="3.14 Remove HTTP Proxy Server (Not Scored)"
	answer=`rpm -q squid`
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""	
}

#3.15 Remove SNMP Server (Not Scored)
CIS74()
{
	logMsg="3.15 Remove SNMP Server (Not Scored)"
	answer=`rpm -q net-snmp`
	if [[ `echo $answer | grep "not"` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""	
}

#3.16 Configure Mail Transfer Agent for Local-Only Mode (Scored)
CIS75()
{
	logMsg="3.16 Configure Mail Transfer Agent for Local-Only Mode (Scored)"
	answer=`netstat -an | grep LIST | grep ":25[[:space:]]"`
	if [[ `echo $answer | grep "LIST"` ]] && [[ `echo $answer | grep 25` ]]
	then
			echo $logMsg: $pass
	else
			echo $logMsg: $fail
	fi
	echo ""	
}


#4.1.1 Disable IP Forwarding (Scored)
CIS76()
{
	logMsg="4.1.1 Disable IP Forwarding (Scored)"
	if [[ `/sbin/sysctl net.ipv4.ip_forward` == "net.ipv4.ip_forward = 0" ]]
	then
		echo $logMsg: $pass
	else	
		echo $logMsg: $fail 
	fi
	echo ""
}

#4.1.2 Disable Send Packet Redirects (Scored)
CIS77()
{
	logMsg="4.1.2 Disable Send Packet Redirects (Scored)"
	if [[ `/sbin/sysctl net.ipv4.ip_forward` == "net.ipv4.ip_forward = 0" ]]
	then
		echo $logMsg: $pass
	else	
		echo $logMsg: $fail 
	fi
	echo ""
}

#4.2 Modify Network Parameters (Host and Router)
#4.2.1 Disable Source Routed Packet Acceptance (Scored)
CIS78()
{
	logMsg="4.2.1 Disable Source Routed Packet Acceptance (Scored)"
	if [[ `/sbin/sysctl net.ipv4.conf.all.accept_source_route` == "net.ipv4.conf.all.accept_source_route = 0" ]] && [[ `/sbin/sysctl net.ipv4.conf.default.accept_source_route` == "net.ipv4.conf.default.accept_source_route = 0" ]]
	then	
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""	
}

#4.2.2 Disable ICMP Redirect Acceptance (Scored)
CIS79()
{
	logMsg="4.2.2 Disable ICMP Redirect Acceptance (Scored)"
	if [[ `/sbin/sysctl net.ipv4.conf.all.accept_redirects` == "net.ipv4.conf.all.accept_redirects = 0" ]] && [[ `/sbin/sysctl net.ipv4.conf.default.accept_redirects` == "net.ipv4.conf.default.accept_redirects = 0" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#4.2.3 Disable Secure ICMP Redirect Acceptance (Scored)
CIS80()
{
	logMsg="4.2.3 Disable Secure ICMP Redirect Acceptance (Scored)"
	if [[ `/sbin/sysctl net.ipv4.conf.all.secure_redirects` == "net.ipv4.conf.all.accept_redirects = 0" ]] && [[ `/sbin/sysctl net.ipv4.conf.default.secure_redirects` == "net.ipv4.conf.default.accept_redirects = 0" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#4.2.4 Log Suspicious Packets (Scored)
CIS81()
{
	logMsg="4.2.4 Log Suspicious Packets (Scored)"
	if [[ `/sbin/sysctl net.ipv4.conf.all.log_martians` == "net.ipv4.conf.all.log_martians = 1" ]] && [[ `/sbin/sysctl net.ipv4.conf.default.log_martians` == "net.ipv4.conf.default.log_martians = 1" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#4.2.5 Enable Ignore Broadcast Requests (Scored)
CIS82()
{
	logMsg="4.2.5 Enable Ignore Broadcast Requests (Scored)"
	if [[ `/sbin/sysctl net.ipv4.icmp_echo_ignore_broadcasts` == "net.ipv4.icmp_echo_ignore_broadcasts = 1" ]] 
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}


#4.2.6 Enable Bad Error Message Protection (Scored)
CIS83()
{
	logMsg="4.2.6 Enable Bad Error Message Protection (Scored)"
	if [[ `/sbin/sysctl net.ipv4.icmp_ignore_bogus_error_responses` == "net.ipv4.icmp_ignore_bogus_error_responses = 1" ]] 
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""	
}


#4.2.7 Enable RFC-recommended Source Route Validation (Scored)
CIS84()
{
	logMsg="4.2.7 Enable RFC-recommended Source Route Validation (Scored)"
	if [[ `/sbin/sysctl net.ipv4.conf.all.rp_filter` == "net.ipv4.conf.all.rp_filter = 1" ]] && [[ `/sbin/sysctl net.ipv4.conf.default.rp_filter` == "net.ipv4.conf.default.rp_filter = 1" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#4.2.8 Enable TCP SYN Cookies (Scored)
CIS85()
{
	logMsg="4.2.8 Enable TCP SYN Cookies (Scored)"
	if [[ `/sbin/sysctl net.ipv4.tcp_syncookies` == "net.ipv4.tcp_syncookies = 1" ]] 
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#4.3 Wireless Networking
#4.3.1 Deactivate Wireless Interfaces (Not Scored)
CIS86()
{
	logMsg="4.3.1 Deactivate Wireless Interfaces (Not Scored)"
	echo $logMsg: "Manual check wireless interfaces"
	ifconfig -a
	#Use the following commands to list all interfaces and identify devices with wireless interfaces. 
	#Once identified, shutdown the interface and remove it
	echo ""
}

#4.4 IPv6
#4.4.1 Configure IPv6
#4.4.1.1 Disable IPv6 Router Advertisements (Not Scored)
CIS87()
{
	logMsg="4.4.1.1 Disable IPv6 Router Advertisements (Not Scored)"
	if [[ `/sbin/sysctl net.ipv6.conf.all.accept_ra` == "net.ipv6.conf.all.accept_ra = 0" ]] && [[ `/sbin/sysctl net.ipv6.conf.default.accept_ra` == "net.ipv6.conf.default.accept_ra = 0" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}


#4.4.1.2 Disable IPv6 Redirect Acceptance (Not Scored)
CIS88()
{
	logMsg="4.4.1.2 Disable IPv6 Redirect Acceptance (Not Scored)"
	if [[ `/sbin/sysctl net.ipv6.conf.all.accept_redirects` == "net.ipv6.conf.all.accept_redirect = 0" ]] && [[ `/sbin/sysctl net.ipv6.conf.default.accept_redirects` == "net.ipv6.conf.default.accept_redirect = 0" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}


#4.4.2 Disable IPv6 (Not Scored)
CIS89()
{
	logMsg="4.4.2 Disable IPv6 (Not Scored)"
	if [[ `/sbin/sysctl net.ipv6.conf.all.accept_redirects` == "net.ipv6.conf.all.disable_ipv6=1" ]] && [[ `sysctl net.ipv6.conf.all.disable_ipv6` == "net.ipv6.conf.all.disable_ipv6=1" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}


#4.5 Install TCP Wrappers
#4.5.1 Install TCP Wrappers (Not Scored)
CIS90()
{
	logMsg="4.5.1 Install TCP Wrappers (Not Scored)"
	answer=`yum list tcp_wrappers`
	if [[ `echo $answer | grep "Installed"` ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}


#4.5.2 Create /etc/hosts.allow (Not Scored)
CIS91()
{
	echo "ALL: <net>/<mask>, <net>/<mask>, …" >/etc/hosts.allow
	echo ""
}


#4.5.3 Verify Permissions on /etc/hosts.allow (Scored)
CIS92()
{
	logMsg="4.5.3 Verify Permissions on /etc/hosts.allow (Scored)"
	if [[ `stat --format '%a' /etc/hosts.allow` == "644" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	
	echo ""
}

#4.5.4 Create /etc/hosts.deny (Not Scored)
CIS93()
{
	logMsg="4.5.4 Create /etc/hosts.deny (Not Scored)"
	if [[ `grep "ALL: ALL" /etc/hosts.deny` == "ALL: ALL" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	
	echo ""
}

#4.5.5 Verify Permissions on /etc/hosts.deny (Scored)
CIS94()
{
	logMsg="4.5.5 Verify Permissions on /etc/hosts.deny (Scored)"
	if [[ `stat --format '%a' /etc/hosts.deny` == "644" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	
	echo ""
}

#4.6 Uncommon Network Protocols
#4.6.1 Disable DCCP (Not Scored)
CIS95()
{
	logMsg="4.6.1 Disable DCCP (Not Scored)"
	if [[ `grep "install dccp /bin/true" /etc/modprobe.d/CIS.conf` == "install dccp /bin/true" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#4.6.2 Disable SCTP (Not Scored)
CIS96()
{
	logMsg="4.6.2 Disable SCTP (Not Scored)"
	if [[ `grep "install sctp /bin/true" /etc/modprobe.d/CIS.conf` == "install sctp /bin/true" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}


#4.6.3 Disable RDS (Not Scored)
CIS97()
{
	logMsg="4.6.3 Disable RDS (Not Scored)"
	if [[ `grep "install rds /bin/true" /etc/modprobe.d/CIS.conf` == "install rds /bin/true" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#4.6.4 Disable TIPC (Not Scored)
CIS98()
{
	logMsg="4.6.4 Disable TIPC (Not Scored)"
	if [[ `grep "install tipc /bin/true" /etc/modprobe.d/CIS.conf` == "install tipc /bin/true" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#4.7 Enable firewalld (Scored)
CIS99()
{
	logMsg="4.7 Enable firewalld (Scored)"
	if [[ `systemctl is-enabled firewalld` == "enabled" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#5 Logging and Auditing
#5.1 Configure rsyslog
#5.1.1 Install the rsyslog package (Scored)
CIS100()
{
	logMsg="5.1.1 Install the rsyslog package (Scored)"
	if [[ `rpm -q rsyslog` == "not" ]]
	then
		echo $logMsg: $fail
	else
		echo $logMsg: $pass
	fi	
	echo ""
}

#5.1.2 Activate the rsyslog Service (Scored)
CIS101()
{
	logMsg="5.1.2 Activate the rsyslog Service (Scored)"
	if [[ `systemctl is-enabled rsyslog` == "enabled" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#5.1.3 Configure /etc/rsyslog.conf (Not Scored)
CIS102()
{
	logMsg="5.1.3 Configure /etc/rsyslog.conf (Not Scored)"
	echo $logMsg: $executed
	echo "Ensure approriate logging is set"
	ls -l /var/log/
	echo ""
}

#5.1.4 Create and Set Permissions on rsyslog Log Files (Scored)
CIS103()
{	
	logMsg="5.1.4 Create and Set Permissions on rsyslog Log Files (Scored)"
	echo $logMsg: "Manual check the log files permission"
	#ls -l <logfile>
	echo ""
}

#5.1.5 Configure rsyslog to Send Logs to a Remote Log Host (Scored)
CIS104()
{
	logMsg="5.1.5 Configure rsyslog to Send Logs to a Remote Log Host (Scored)"
	grep "^*.*[^I][^I]*@" /etc/rsyslog.conf
	echo $logMsg: $executed
	echo "Review the /etc/rsyslog.conf file and verify that logs are sent to a central host (where logfile.example.com is the name of your central log host)."
	echo ""
}

#5.1.6 Accept Remote rsyslog Messages Only on Designated Log Hosts (Not Scored)
CIS105()
{
	logMsg="5.1.6 Accept Remote rsyslog Messages Only on Designated Log Hosts (Not Scored)"
	if [[ `grep '$ModLoad imtcp.so' /etc/rsyslog.conf` == "$ModLoad imtcp.so" ]] && [[ `grep '$InputTCPServerRun' /etc/rsyslog.conf` == "$InputTCPServerRun 514" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#5.2 Configure System Accounting (auditd)
#5.2.1 Configure Data Retention
#5.2.1.1 Configure Audit Log Storage Size (Not Scored)
CIS106()
{
	logMsg="5.2.1.1 Configure Audit Log Storage Size (Not Scored)"
	grep max_log_file /etc/audit/auditd.conf
	echo $logMsg: "Depends on maximum size required"
	echo ""
}

#5.2.1.2 Disable System on Audit Log Full (Not Scored)
CIS107()
{
	logMsg="5.2.1.2 Disable System on Audit Log Full (Not Scored)"
	if [[ `grep space_left_action /etc/audit/auditd.conf` == "space_left_action = email" ]] && [[ `grep action_mail_acct /etc/audit/auditd.conf` == "action_mail_acct = root" ]] && [[ `grep admin_space_left_action /etc/audit/auditd.conf` == "admin_space_left_action = halt" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#5.2.1.3 Keep All Auditing Information (Scored)
CIS108()
{
	logMsg="5.2.1.3 Keep All Auditing Information (Scored)"
	if [[ `grep max_log_file_action /etc/audit/auditd.conf` == "max_log_file_action = keep_logs" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#5.2.2 Enable auditd Service (Scored)
CIS109()
{
	logMsg="5.2.2 Enable auditd Service (Scored)"
	if [[ `systemctl is-enabled auditd` == "enabled" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi	
	echo ""
}

#5.2.3 Enable Auditing for Processes That Start Prior to auditd (Scored)
CIS110()
{
	logMsg="5.2.3 Enable Auditing for Processes That Start Prior to auditd (Scored)"
	echo $logMsg: $executed 
	echo "Make sure each line that starts with linux has the audit=1 parameter set."
	grep "linux" /boot/grub2/grub.cfg
	echo ""
}

#5.2.4 Record Events That Modify Date and Time Information (Scored)
CIS111()
{
	logMsg="5.2.4 Record Events That Modify Date and Time Information (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep time-change /etc/audit/audit.rules	
	pkill -P 1-HUP auditd
	echo ""
}

#5.2.5 Record Events That Modify User/Group Information (Scored)
CIS112_()
{
	logMsg="5.2.5 Record Events That Modify User/Group Information (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep identity /etc/audit/audit.rules
	echo ""
}


#5.2.6 Record Events That Modify the System's Network Environment (Scored)
CIS112()
{
	logMsg="5.2.6 Record Events That Modify the System's Network Environment (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep system-locale /etc/audit/audit.rules
	echo ""
}

#5.2.7 Record Events That Modify the System's Mandatory Access Controls (Scored)
CIS113()
{
	logMsg="5.2.7 Record Events That Modify the System's Mandatory Access Controls (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep MAC-policy /etc/audit/audit.rules
	echo ""
}

#5.2.8 Collect Login and Logout Events (Scored)
CIS114()
{
	logMsg="5.2.8 Collect Login and Logout Events (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep logins /etc/audit/audit.rules
	echo ""
}


#5.2.9 Collect Session Initiation Information (Scored)
CIS115()
{
	logMsg="5.2.9 Collect Session Initiation Information (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep session /etc/audit/audit.rules
	echo ""
}

#5.2.10 Collect Discretionary Access Control Permission Modification Events (Scored)
CIS116()
{
	logMsg="5.2.10 Collect Discretionary Access Control Permission Modification Events (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep perm_mod /etc/audit/audit.rules
	echo ""
}

#5.2.11 Collect Unsuccessful Unauthorized Access Attempts to Files (Scored)
CIS117()
{
	logMsg="5.2.11 Collect Unsuccessful Unauthorized Access Attempts to Files (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep access /etc/audit/audit.rules
	echo ""
}

#5.2.12 Collect Use of Privileged Commands (Scored)
CIS118()
{
	logMsg="5.2.12 Collect Use of Privileged Commands (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	find PART -xdev \( -perm -4000 -o -perm -2000 \) -type f | awk '{print \ "-a always,exit -F path=" $1 " -F perm=x -F auid>=500 -F auid!=4294967295 \ -k privileged" }'
	echo ""
}

#5.2.13 Collect Successful File System Mounts (Scored)
CIS119()
{
	logMsg="5.2.13 Collect Successful File System Mounts (Scored)"
	echo $logMsg: $executed 
	echo "Manual Check"
	grep mounts /etc/audit/audit.rules
	echo ""
}

#5.2.14 Collect File Deletion Events by User (Scored)
CIS120()
{
	logMsg="5.2.14 Collect File Deletion Events by User (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep delete /etc/audit/audit.rules
	echo ""
}

#5.2.15 Collect Changes to System Administration Scope (sudoers) (Scored)
CIS121()
{
	logMsg="5.2.15 Collect Changes to System Administration Scope (sudoers) (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep scope /etc/audit/audit.rules
	echo ""
}


#5.2.16 Collect System Administrator Actions (sudolog) (Scored)
CIS122()
{	
	logMsg="5.2.16 Collect System Administrator Actions (sudolog) (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep actions /etc/audit/audit.rules
	echo ""

}

#5.2.17 Collect Kernel Module Loading and Unloading (Scored)
CIS123()
{
	logMsg="5.2.17 Collect Kernel Module Loading and Unloading (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep modules /etc/audit/audit.rules
	echo ""
}

#5.2.18 Make the Audit Configuration Immutable (Scored)
CIS124()
{
	logMsg="5.2.18 Make the Audit Configuration Immutable (Scored)"
	if [[ `grep "^-e 2" /etc/audit/audit.rules` == "-e 2" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#5.3 Configure logrotate (Not Scored)
CIS125()
{
	logMsg="5.2.18 Make the Audit Configuration Immutable (Scored)"
	if [[ `grep '{' /etc/logrotate.d/syslog` == "/var/log/messages /var/log/secure /var/log/maillog /var/log/spooler /var/log/boot.log /var/log/cron {" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""

}

#6 System Access, Authentication and Authorization
#6.1 Configure cron and anacron
#6.1.1 Enable anacron Daemon (Scored)
CIS126()
{
	logMsg="6.1.1 Enable anacron Daemon (Scored)"
	answer=`rpm -q cronie-anacron`
	if [[ `echo $answer | grep "not"` ]]
	then
		echo $logMsg: $fail
	else
		echo $logMsg: $pass
	fi
	echo ""
}

#6.1.2 Enable crond Daemon (Scored)
CIS127()
{
	logMsg="6.1.2 Enable crond Daemon (Scored)"
	if [[ `systemctl is-enabled crond` == "enabled" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""

}

#6.1.3 Set User/Group Owner and Permission on /etc/anacrontab (Scored)
CIS128()
{
	logMsg="6.1.3 Set User/Group Owner and Permission on /etc/anacrontab (Scored)"
	if [[ `stat -L -c "%a %u %g" /etc/anacrontab | egrep ".00 0 0"` == "" ]]
	then
		echo $logMsg: $fail
	else
		echo $logMsg: $pass
	fi
	echo ""
}


#6.1.4 Set User/Group Owner and Permission on /etc/crontab (Scored)
CIS129()
{
	logMsg="6.1.4 Set User/Group Owner and Permission on /etc/crontab (Scored)"
	if [[ `stat -L -c "%a %u %g" /etc/crontab | egrep ".00 0 0"` == "" ]]
	then
		echo $logMsg: $fail
	else
		echo $logMsg: $pass
	fi
	echo ""

}

#6.1.5 Set User/Group Owner and Permission on /etc/cron.hourly (Scored)
CIS130()
{
	logMsg="66.1.5 Set User/Group Owner and Permission on /etc/cron.hourly (Scored)"
	if [[ `stat -L -c "%a %u %g" /etc/cron.hourly | egrep ".00 0 0"` == "" ]]
	then
		echo $logMsg: $fail
	else
		echo $logMsg: $pass
	fi
	echo ""
}

#6.1.6 Set User/Group Owner and Permission on /etc/cron.daily (Scored)
CIS131()
{
	logMsg="6.1.6 Set User/Group Owner and Permission on /etc/cron.daily (Scored)"
	if [[ `stat -L -c "%a %u %g" /etc/cron.daily | egrep ".00 0 0"` == "" ]]
	then
		echo $logMsg: $fail
	else
		echo $logMsg: $pass
	fi
	echo ""
}

#6.1.7 Set User/Group Owner and Permission on /etc/cron.weekly (Scored)
CIS132()
{
	logMsg="6.1.7 Set User/Group Owner and Permission on /etc/cron.weekly (Scored)"
	if [[ `stat -L -c "%a %u %g" /etc/cron.weekly | egrep ".00 0 0"` == "" ]]
	then
		echo $logMsg: $fail
	else
		echo $logMsg: $pass
	fi
	echo ""
}

#6.1.8 Set User/Group Owner and Permission on /etc/cron.monthly (Scored)
CIS133()
{
	logMsg="6.1.8 Set User/Group Owner and Permission on /etc/cron.monthly (Scored)"
	if [[ `stat -L -c "%a %u %g" /etc/cron.monthly | egrep ".00 0 0"` == "" ]]
	then
		echo $logMsg: $fail
	else
		echo $logMsg: $pass
	fi
	echo ""
}

#6.1.9 Set User/Group Owner and Permission on /etc/cron.d (Scored)
CIS134()
{
	logMsg="6.1.9 Set User/Group Owner and Permission on /etc/cron.d (Scored)"
	if [[ `stat -L -c "%a %u %g" /etc/cron.d | egrep ".00 0 0"` == "" ]]
	then
		echo $logMsg: $fail
	else
		echo $logMsg: $pass
	fi
	echo ""

}

#6.1.10 Restrict at Daemon (Scored)
CIS135()
{
	logMsg="6.1.10 Restrict at Daemon (Scored)"
	
	if [[ `stat -L -c "%a %u %g" /etc/at.allow | egrep ".00 0 0"` == "" ]] && [[ `stat -L -c "%a %u %g" /etc/at.allow | egrep ".00 0 0"` == "" ]]
	then
		echo $logMsg: $fail
	else
		echo $logMsg: $pass
	fi
	echo ""
}


#6.1.11 Restrict at/cron to Authorized Users (Scored)
CIS136()
{
	logMsg="6.1.11 Restrict at/cron to Authorized Users (Scored)"
	if [[ `ls -l /etc/cron.deny` == "" ]]  && [[ `ls -l /etc/at.deny` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	
	ls -l /etc/cron.allow
	ls -l /etc/at.allow
	echo ""
}

#6.2 Configure SSH
#6.2.1 Set SSH Protocol to 2 (Scored)
CIS137()
{
	logMsg="6.2.1 Set SSH Protocol to 2 (Scored)"

	if [[ `grep "^Protocol" /etc/ssh/sshd_config` == "Protocol 2" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#6.2.2 Set LogLevel to INFO (Scored)
CIS138()
{
	logMsg="6.2.2 Set LogLevel to INFO (Scored)"

	if [[ `grep "^LogLevel" /etc/ssh/sshd_config` == "LogLevel INFO" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}


#6.2.3 Set Permissions on /etc/ssh/sshd_config (Scored)
CIS139()
{
	logMsg="6.2.3 Set Permissions on /etc/ssh/sshd_config (Scored)"
	answer=`/bin/ls -l /etc/ssh/sshd_config`
	if [[ `stat --format '%a' /etc/ssh/sshd_config` == "600" ]] && [[ `echo $answer | grep root` == *"root"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
	
}

#6.2.4 Disable SSH X11 Forwarding (Scored)
CIS140()
{
	logMsg="6.2.4 Disable SSH X11 Forwarding (Scored)"
	
	if [[ `grep "^X11Forwarding" /etc/ssh/sshd_config` == *"X11Forwarding no"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}


#6.2.5 Set SSH MaxAuthTries to 4 or Less (Scored)
CIS141()
{
	logMsg="6.2.5 Set SSH MaxAuthTries to 4 or Less (Scored)"
	if [[ `grep "^MaxAuthTries" /etc/ssh/sshd_config` == *"MaxAuthTries 4"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#6.2.6 Set SSH IgnoreRhosts to Yes (Scored)
CIS142()
{
	logMsg="6.2.6 Set SSH IgnoreRhosts to Yes (Scored)"
	if [[ `grep "^IgnoreRhosts" /etc/ssh/sshd_config` == *"IgnoreRhosts yes"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#6.2.7 Set SSH HostbasedAuthentication to No (Scored)
CIS143()
{
	logMsg="6.2.6 Set SSH IgnoreRhosts to Yes (Scored)"
	if [[ `grep "^HostbasedAuthentication" /etc/ssh/sshd_config` == *"HostbasedAuthentication no"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#6.2.8 Disable SSH Root Login (Scored)
CIS144()
{
	logMsg="6.2.8 Disable SSH Root Login (Scored)"
	if [[ `grep "^PermitRootLogin" /etc/ssh/sshd_config` == *"PermitRootLogin no"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#6.2.9 Set SSH PermitEmptyPasswords to No (Scored)
CIS145()
{
	logMsg="6.2.9 Set SSH PermitEmptyPasswords to No (Scored)"
	if [[ `grep "^PermitEmptyPasswords" /etc/ssh/sshd_config` == *"PermitEmptyPasswords no"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#6.2.10 Do Not Allow Users to Set Environment Options (Scored)
CIS146()
{
	logMsg="6.2.10 Do Not Allow Users to Set Environment Options (Scored)"
	if [[ `grep PermitUserEnvironment /etc/ssh/sshd_config` == *"PermitUserEnvironment no"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#6.2.11 Use Only Approved Cipher in Counter Mode (Scored)
CIS147()
{
	logMsg="6.2.11 Use Only Approved Cipher in Counter Mode (Scored)"
	if [[ `grep "Ciphers" /etc/ssh/sshd_config` == *"Ciphers aes128-ctr,aes192-ctr,aes256-ctr"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#6.2.12 Set Idle Timeout Interval for User Login (Scored)
CIS148()
{
	logMsg="6.2.12 Set Idle Timeout Interval for User Login (Scored)"
	if [[ `grep "^ClientAliveInterval" /etc/ssh/sshd_config` == *"ClientAliveInterval 300"* ]] && [[ `grep "^ClientAliveCountMax" /etc/ssh/sshd_config` == *"ClientAliveCountMax 0"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""

}

#6.2.13 Limit Access via SSH (Scored)
CIS149()
{
	logMsg="6.2.13 Limit Access via SSH (Scored)"
	echo $logMsg: $executed
	grep "^AllowUsers" /etc/ssh/sshd_config
	grep "^AllowGroups" /etc/ssh/sshd_config
	grep "^DenyUsers" /etc/ssh/sshd_config
	grep "^DenyGroups" /etc/ssh/sshd_config
	echo ""
}

#6.2.14 Set SSH Banner (Scored)
CIS150()
{
	
	logMsg="6.2.14 Set SSH Banner (Scored)"
	if [[ `grep "^Banner" /etc/ssh/sshd_config` == *"Banner /etc/issue"* ]] || [[ `grep "^Banner" /etc/ssh/sshd_config` == *"Banner /etc/issue.net"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#6.3 Configure PAM
#6.3.1 Upgrade Password Hashing Algorithm to SHA-512 (Scored)
CIS151()
{
	logMsg="6.3.1 Upgrade Password Hashing Algorithm to SHA-512 (Scored)"
	if [[ `authconfig --test | grep hashing | grep sha512` == *"sha512"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#6.3.2 Set Password Creation Requirement Parameters Using pam_cracklib (Scored)
CIS152()
{
	logMsg="6.3.2 Set Password Creation Requirement Parameters Using pam_cracklib (Scored)"
	if [[ `grep pam_cracklib.so /etc/pam.d/system-auth` == *"password required pam_cracklib.so try_first_pass retry=3 minlen=14 dcredit=-1 ucredit=-1 ocredit=-1 lcredit=-1"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}


#6.3.3 Set Lockout for Failed Password Attempts (Not Scored)
CIS153()
{
	logMsg="6.3.3 Set Lockout for Failed Password Attempts (Not Scored)"
	if [[ `grep "pam_faillock" /etc/pam.d/password-auth` == *"auth required pam_faillock.so preauth audit silent deny=5 unlock_time=900 auth [default=die] pam_faillock.so authfail audit deny=5 unlock_time=900 auth sufficient pam_faillock.so authsucc audit deny=5 unlock_time=900"* ]] && [[ `grep "pam_unix.so" /etc/pam.d/password-auth | grep success=1` == *"auth [success=1 default=bad] pam_unix.so"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#6.3.4 Limit Password Reuse (Scored)
CIS154()
{
	logMsg="6.3.4 Limit Password Reuse (Scored)"
	if [[ `grep "remember" /etc/pam.d/system_auth` == *"password sufficient pam_unix.so remember=5"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}


#6.4 Restrict root Login to System Console (Not Scored)
CIS155()
{
	logMsg="6.4 Restrict root Login to System Console (Not Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	cat /etc/securetty
	echo ""
}


#6.5 Restrict Access to the su Command (Scored)
CIS156()
{
	logMsg="6.5 Restrict Access to the su Command (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep pam_wheel.so /etc/pam.d/su
	grep wheel /etc/group
	echo ""
}


#7 User Accounts and Environment
#7.1 Set Shadow Password Suite Parameters (/etc/login.defs)
#7.1.1 Set Password Expiration Days (Scored)
CIS157()
{
	logMsg="7.1.1 Set Password Expiration Days (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep PASS_MAX_DAYS /etc/login.defs
	#chage --list <user>
	
	echo "" 
}

#7.1.2 Set Password Change Minimum Number of Days (Scored)
CIS158()
{
	logMsg="7.1.2 Set Password Change Minimum Number of Days (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	grep PASS_MIN_DAYS /etc/login.defs
	
	echo ""
}


#7.1.3 Set Password Expiring Warning Days (Scored)
CIS159()
{
	logMsg="7.1.3 Set Password Expiring Warning Days (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	#chage --list <user>
	grep PASS_WARN_AGE /etc/login.defs
	
	echo ""
}


#7.2 Disable System Accounts (Scored)
CIS160()
{
	logMsg="7.2 Disable System Accounts (Scored)"
	if [[ `egrep -v "^\+" /etc/passwd | awk -F: '($1!="root" && $1!="sync" && $1!="shutdown" && $1!="halt" && $3<500 && $7!="/sbin/nologin") {print}'` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""

}

#7.3 Set Default Group for root Account (Scored)
CIS161()
{
	logMsg="7.3 Set Default Group for root Account (Scored)"
	if [[ `grep "^root:" /etc/passwd | cut -f4 -d:` == "0" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#7.4 Set Default umask for Users (Scored)
CIS162()
{
	logMsg="7.4 Set Default umask for Users (Scored)"
	if [[ `grep "^umask 077" /etc/bashrc` == *"umask 077"* ]] && [[ `grep "^umask 077" /etc/profile.d/*` == *"umask 077"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#7.5 Lock Inactive User Accounts (Scored)
CIS163()
{
	logMsg="7.5 Lock Inactive User Accounts (Scored)"
	if [[ `useradd -D | grep INACTIVE` == *"INACTIVE=35"* ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#8 Warning Banners
#8.1 Set Warning Banner for Standard Login Services (Scored)
CIS164()
{
	logMsg="8.1 Set Warning Banner for Standard Login Services (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	echo "Ensure that the files exist and have the correct permissions"
	/bin/ls -l /etc/motd
	ls /etc/issue
	ls /etc/issue.net
	echo ""
}


#8.2 Remove OS Information from Login Warning Banners (Scored)
CIS165()
{
	logMsg="8.2 Remove OS Information from Login Warning Banners (Scored)"
	echo $logMsg: $executed
	echo "Manual Check"
	echo "Check if OS information is set to be displayed in the system login banners"
	egrep '(\\v|\\r|\\m|\\s)' /etc/issue
	egrep '(\\v|\\r|\\m|\\s)' /etc/motd
	egrep '(\\v|\\r|\\m|\\s)' /etc/issue.net
	
	echo ""
}

#8.3 Set GNOME Warning Banner (Not Scored)
CIS166()
{
	logMsg="8.3 Set GNOME Warning Banner (Not Scored)"
	echo $logMsg: $executed
	gconftool-2 -get /apps/gdm/simple-greeter/banner_message_text
	echo ""
}


#9 System Maintenance
#9.1 Verify System File Permissions
#9.1.1 Verify System File Permissions (Not Scored)
CIS167()
{
	logMsg="9.1.1 Verify System File Permissions (Not Scored)"
	#rpm -Va --nomtime --nosize --nomd5 --nolinkto > <filename>
	echo $logMsg: $executed
	echo "Manual Check"
}

#9.1.2 Verify Permissions on /etc/passwd (Scored)
CIS168()
{
	logMsg="9.1.2 Verify Permissions on /etc/passwd (Scored)"
	if [[ `stat --format '%a' /etc/passwd` == "644" ]] 
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	
	/bin/ls -l /etc/passwd
	echo ""
}

#9.1.3 Verify Permissions on /etc/shadow (Scored)
CIS169()
{
	logMsg="9.1.3 Verify Permissions on /etc/shadow (Scored)"
	if [[ `stat --format '%a' /etc/shadow` == "0" ]] 
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	
	/bin/ls -l /etc/shadow
	echo ""
}

#9.1.4 Verify Permissions on /etc/gshadow (Scored)
CIS170()
{
	logMsg="9.1.4 Verify Permissions on /etc/gshadow (Scored)"
	if [[ `stat --format '%a' /etc/gshadow` == "0" ]] 
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	
	/bin/ls -l /etc/gshadow
	echo ""
}

#9.1.5 Verify Permissions on /etc/group (Scored)
CIS171()
{
	logMsg="9.1.4 Verify Permissions on /etc/gshadow (Scored)"
	if [[ `stat --format '%a' /etc/group` == "644" ]] 
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	
	/bin/ls -l /etc/group
	echo ""
}


#9.1.6 Verify User/Group Ownership on /etc/passwd (Scored)
CIS172()
{
	logMsg="9.1.6 Verify User/Group Ownership on /etc/passwd (Scored)"
	echo $logMsg: $executed
	/bin/ls -l /etc/passwd
	echo ""	
}

#9.1.7 Verify User/Group Ownership on /etc/shadow (Scored)
CIS173()
{
	logMsg="9.1.7 Verify User/Group Ownership on /etc/shadow (Scored)"
	echo $logMsg: $executed
	/bin/ls -l /etc/shadow
	echo ""
}

#9.1.8 Verify User/Group Ownership on /etc/gshadow (Scored)
CIS174()
{
	logMsg="9.1.7 Verify User/Group Ownership on /etc/shadow (Scored)"
	echo $logMsg: $executed
	/bin/ls -l /etc/gshadow
	echo ""
}

#9.1.9 Verify User/Group Ownership on /etc/group (Scored)
CIS175()
{
	logMsg="9.1.9 Verify User/Group Ownership on /etc/group (Scored)"
	echo $logMsg: $executed
	/bin/ls -l /etc/group
	echo ""
}

#9.1.10 Find World Writable Files (Not Scored)
CIS176()
{
	logMsg="9.1.10 Find World Writable Files (Not Scored)"
	echo $logMsg: $executed
	df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type f -perm -0002
	echo ""
}

#9.1.11 Find Un-owned Files and Directories (Scored)
CIS177()
{
	logMsg="9.1.11 Find Un-owned Files and Directories (Scored)"
	echo $logMsg: $executed
	df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -nouser -ls
	echo ""
}

#9.1.12 Find Un-grouped Files and Directories (Scored)
CIS178()
{
	logMsg="9.1.12 Find Un-grouped Files and Directories (Scored)"
	echo $logMsg: $executed
	df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -nogroup -ls
	echo ""
}

#9.1.13 Find SUID System Executables (Not Scored)
CIS179()
{
	logMsg="9.1.13 Find SUID System Executables (Not Scored)"
	echo $logMsg: $executed
	echo "Identify and review such programs to ensure they are legitimate"
	df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type f -perm -4000 -print
	echo ""
}

#9.1.14 Find SGID System Executables (Not Scored)
CIS180()
{
	logMsg="9.1.14 Find SGID System Executables (Not Scored)"
	echo $logMsg: $executed
	echo "Review the files and check to see if system binaries have a different md5 checksum than what from the package"
	rpm -V `rpm -qf /usr/bin/sudo`
	echo ""
}

#9.2 Review User and Group Settings
#9.2.1 Ensure Password Fields are Not Empty (Scored)
CIS181()
{
	logMsg="9.2.1 Ensure Password Fields are Not Empty (Scored)"
	if [[ `/bin/cat /etc/shadow | /bin/awk -F: '($2 == "" ) { print $1 " does not have a password "}'` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#9.2.2 Verify No Legacy "+" Entries Exist in /etc/passwd File (Scored)
CIS182()
{
	logMsg="9.2.2 Verify No Legacy "+" Entries Exist in /etc/passwd File (Scored)"
	if [[ `/bin/grep '^+:' /etc/passwd` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""	
}

#9.2.3 Verify No Legacy "+" Entries Exist in /etc/shadow File (Scored)
CIS183()
{
	logMsg="9.2.3 Verify No Legacy "+" Entries Exist in /etc/shadow File (Scored)"
	if [[ `/bin/grep '^+:' /etc/shadow` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#9.2.4 Verify No Legacy "+" Entries Exist in /etc/group File (Scored)
CIS184()
{
	logMsg="9.2.4 Verify No Legacy "+" Entries Exist in /etc/group File (Scored)"
	if [[ `/bin/grep '^+:' /etc/group` == "" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#9.2.5 Verify No UID 0 Accounts Exist Other Than root (Scored)
CIS185()
{
	logMsg="9.2.5 Verify No UID 0 Accounts Exist Other Than root (Scored)"
	if [[ `/bin/cat /etc/passwd | /bin/awk -F: '($3 == 0) { print $1 }'` == "root" ]]
	then
		echo $logMsg: $pass
	else
		echo $logMsg: $fail
	fi
	echo ""
}

#9.2.6 Ensure root PATH Integrity (Scored)
CIS186()
{
	logMsg="9.2.6 Ensure root PATH Integrity (Scored)"
	echo $logMsg: $executed
	
	if [ "`echo $PATH | /bin/grep :: `" != "" ]; then 
		echo "Empty Directory in PATH (::)" 
	fi 

	if [ "`echo $PATH | bin/grep :$`" != "" ]; then 
		echo "Trailing : in PATH" 
	fi 
	p=`echo $PATH | /bin/sed -e 's/::/:/' -e 's/:$//' -e 's/:/ /g'` 
	set -- $p 
	while [ "$1" != "" ]; do 
		if [ "$1" = "." ]; then 
			echo "PATH contains ." 
			shift 
			continue 
		fi 
		if [ -d $1 ]; then 
			dirperm=`/bin/ls -ldH $1 | /bin/cut -f1 -d" "` 
			if [ `echo $dirperm | /bin/cut -c6 ` != "-" ]; then 
				echo "Group Write permission set on directory $1" 
			fi 
			if [ `echo $dirperm | /bin/cut -c9 ` != "-" ]; then 
				echo "Other Write permission set on directory $1" 
			fi 
		
			dirown=`ls -ldH $1 | awk '{print $3}'` 
			if [ "$dirown" != "root" ] ; then 
				echo $1 is not owned by root 
			fi 
		else 
			echo $1 is not a directory
		fi 
		shift		
	done
	
	echo ""
}

#9.2.7 Check Permissions on User Home Directories (Scored)
CIS187()
{
	logMsg="9.2.7 Check Permissions on User Home Directories (Scored)"
	echo $logMsg: $executed
	for dir in `/bin/cat /etc/passwd | /bin/egrep -v '(root|halt|sync|shutdown)' |\ /bin/awk -F: '($8 == "PS" && $7 != "/sbin/nologin") { print $6 }'`; do 
		dirperm=`/bin/ls -ld $dir | /bin/cut -f1 -d" "` 
		if [ `echo $dirperm | /bin/cut -c6 ` != "-" ]; then 
			echo "Group Write permission set on directory $dir" 
		fi 
		if [ `echo $dirperm | /bin/cut -c8 ` != "-" ]; then 
			echo "Other Read permission set on directory $dir" 
		fi 
		if [ `echo $dirperm | /bin/cut -c9 ` != "-" ]; then 
			echo "Other Write permission set on directory $dir" 
		fi 
		if [ `echo $dirperm | /bin/cut -c10 ` != "-" ]; then 
		echo "Other Execute permission set on directory $dir" 
		fi 
	done
	
	echo ""
}


#9.2.8 Check User Dot File Permissions (Scored)
CIS188()
{
	logMsg="9.2.8 Check User Dot File Permissions (Scored)"
	echo $logMsg: $executed
	
	for dir in `/bin/cat /etc/passwd | /bin/egrep -v '(root|sync|halt|shutdown)' | 
		/bin/awk -F: '($7 != "/sbin/nologin") { print $6 }'`; do 
		for file in $dir/.[A-Za-z0-9]*; do 
			if [ ! -h "$file" -a -f "$file" ]; then 
				fileperm=`/bin/ls -ld $file | /bin/cut -f1 -d" "` 
				
				if [ `echo $fileperm | /bin/cut -c6 ` != "-" ]; then 
					echo "Group Write permission set on file $file" 
				fi 
				
				if [ `echo $fileperm | /bin/cut -c9 ` != "-" ]; then 
					echo "Other Write permission set on file $file" 
				fi 
			fi 
		done 
	done
	
	echo ""
}

#9.2.9 Check Permissions on User .netrc Files (Scored)
CIS189()
{
	logMsg="9.2.9 Check Permissions on User .netrc Files (Scored)"
	echo $logMsg: $executed
	for dir in `/bin/cat /etc/passwd | /bin/egrep -v '(root|sync|halt|shutdown)' |\ /bin/awk -F: '($7 != "/sbin/nologin") { print $6 }'`; do 
		for file in $dir/.netrc; do 
		if [ ! -h "$file" -a -f "$file" ]; then 
			fileperm=`/bin/ls -ld $file | /bin/cut -f1 -d" "` 
			
			if [ `echo $fileperm | /bin/cut -c5 ` != "-" ]; then 
				echo "Group Read set on $file" 
			fi 
			
			if [ `echo $fileperm | /bin/cut -c6 ` != "-" ]; then 
				echo "Group Write set on $file" 
			fi 
			
			if [ `echo $fileperm | /bin/cut -c7 ` != "-" ]; then 
				echo "Group Execute set on $file" 
			fi 
			
			if [ `echo $fileperm | /bin/cut -c8 ` != "-" ]; then 
				echo "Other Read set on $file" 
			fi 
			
			if [ `echo $fileperm | /bin/cut -c9 ` != "-" ]; then 
				echo "Other Write set on $file" 
			fi 
			
			if [ `echo $fileperm | /bin/cut -c10 ` != "-" ]; then 
				echo "Other Execute set on $file" 
			fi 
		fi 
		done 
	done

	echo ""
}

#9.2.10 Check for Presence of User .rhosts Files (Scored)
CIS190()
{
	logMsg="9.2.10 Check for Presence of User .rhosts Files (Scored)"
	echo $logMsg: $executed
	
	for dir in `/bin/cat /etc/passwd | /bin/egrep -v '(root|halt|sync|shutdown)' |\ /bin/awk -F: '($7 != "/sbin/nologin") { print $6 }'`; do 
		for file in $dir/.rhosts; do 
			if [ ! -h "$file" -a -f "$file" ]; then 
				echo ".rhosts file in $dir" 
			fi 
		done 
	done
}

#9.2.11 Check Groups in /etc/passwd (Scored)
CIS191()
{
	logMsg="9.2.11 Check Groups in /etc/passwd (Scored)"
	echo $logMsg: $executed
	
	for i in $(cut -s -d: -f4 /etc/passwd | sort -u ); do 
		grep -q -P "^.*?:x:$i:" /etc/group 
		if [ $? -ne 0 ]; then 
			echo "Group $i is referenced by /etc/passwd but does not exist in /etc/group" 
		fi 
	done	
	
	echo ""
}


#9.2.12 Check That Users Are Assigned Valid Home Directories (Scored)
CIS192()
{
	logMsg="9.2.12 Check That Users Are Assigned Valid Home Directories (Scored)"
	echo $logMsg: $executed
	
	cat /etc/passwd | awk -F: '{ print $1 " " $3 " " $6 }' | while read user uid dir; do 
		if [ $uid -ge 1000 -a ! -d "$dir" -a $user != "nfsnobody" ]; then 
			echo "The home directory ($dir) of user $user does not exist." 
		fi 
	done
	
	echo ""
}


#9.2.13 Check User Home Directory Ownership (Scored)
CIS193()
{
	logMsg="9.2.13 Check User Home Directory Ownership (Scored)"
	echo $logMsg: $executed
	
	cat /etc/passwd | awk -F: '{ print $1 " " $3 " " $6 }' | while read user uid dir; do 
		if [ $uid -ge 1000 -a -d "$dir" -a $user != "nfsnobody" ]; then 
			owner=$(stat -L -c "%U" "$dir") 
		if [ "$owner" != "$user" ]; then 
				echo "The home directory ($dir) of user $user is owned by $owner." 
		fi 
	fi 
	done
	
	echo ""
}

#9.2.14 Check for Duplicate UIDs (Scored)
CIS194()
{
	logMsg="9.2.14 Check for Duplicate UIDs (Scored)"
	echo $logMsg: $executed
	
	echo "The Output for the Audit of Control 9.2.15 - Check for Duplicate UIDs is" /bin/cat /etc/passwd | /bin/cut -f3 -d":" | /bin/sort -n | /usr/bin/uniq -c |\
	while read x ; do 
	[ -z "${x}" ] && break 
	set - $x 
	if [ $1 -gt 1 ]; then 
		users=`/bin/gawk -F: '($3 == n) { print $1 }' n=$2 \ /etc/passwd | /usr/bin/xargs` 
		echo "Duplicate UID ($2): ${users}" 
	fi 
	done
	
	echo ""
}

#9.2.15 Check for Duplicate GIDs (Scored)
CIS195()
{
	logMsg="9.2.15 Check for Duplicate GIDs (Scored)"
	echo $logMsg: $executed
	
	echo "The Output for the Audit of Control 9.2.16 - Check for Duplicate GIDs is" /bin/cat /etc/group | /bin/cut -f3 -d ":" | /bin/sort -n | /usr/bin/uniq -c |\ 
	while read x ; do 
	[ -z "${x}" ] && break 
	set - $x 
	if [ $1 -gt 1 ]; then 
		grps=`/bin/gawk -F: '($3 == n) { print $1 }' n=$2 \ /etc/group | xargs` 
		echo "Duplicate GID ($2): ${grps}"
	fi
	done
	
	echo ""
}

#9.2.16 Check That Reserved UIDs Are Assigned to System Accounts (Scored)
CIS196()
{
	logMsg="9.2.16 Check That Reserved UIDs Are Assigned to System Accounts (Scored)"
	echo $logMsg: $executed
	
	echo "The Output for the Audit of Control 9.2.17 - Check That Reserved UIDS Are Assigned to System Accounts is" 
	defUsers="root bin daemon adm lp sync shutdown halt mail news uucp operator games gopher ftp nobody nscd vcsa rpc mailnull smmsp pcap ntp dbus avahi sshd rpcuser nfsnobody haldaemon avahi-autoipd distcache apache oprofile webalizer dovecot squid named xfs gdm sabayon usbmuxd rtkit abrt saslauth pulse postfix tcpdump" 
	/bin/cat /etc/passwd |\ /bin/awk -F: '($3 < 500) { print $1" "$3 }' |\ 
		while read user uid; do 
		found=0 
		for tUser in ${defUsers} 
			do 
				if [ ${user} = ${tUser} ]; then 
					found=1 
				fi 
			done 
				if [ $found -eq 0 ]; then 
					echo "User $user has a reserved UID ($uid)." 
				fi 
		done
		
	echo ""
}

#9.2.17 Check for Duplicate User Names (Scored)
CIS197()
{
	logMsg="9.2.17 Check for Duplicate User Names (Scored)"
	echo $logMsg: $executed
	
	echo "The Output for the Audit of Control 9.2.18 - Check for Duplicate User Names is" 
	cat /etc/passwd | cut -f1 -d":" | /bin/sort -n | /usr/bin/uniq -c |\ 
	while read x ; do 
	[ -z "${x}" ] && break set - $x 
	if [ $1 -gt 1 ]; then 
		uids=`/bin/gawk -F: '($1 == n) { print $3 }' n=$2 \ /etc/passwd | xargs` 
		echo "Duplicate User Name ($2): ${uids}" 
	fi 
	done
	
	echo ""
}

#9.2.18 Check for Duplicate Group Names (Scored)
CIS198()
{
	logMsg="9.2.18 Check for Duplicate Group Names (Scored)"
	echo $logMsg: $executed
	
	echo "The Output for the Audit of Control 9.2.19 - Check for Duplicate Group Names is" 
	cat /etc/group | cut -f1 -d":" | /bin/sort -n | /usr/bin/uniq -c |\ 
		while read x ; do
			[ -z "${x}" ] && break 
		set - $x 
		if [ $1 -gt 1 ]; then 
		gids=`/bin/gawk -F: '($1 == n) { print $3 }' n=$2 \ /etc/group | xargs` 
			echo "Duplicate Group Name ($2): ${gids}" 
		fi 
		done
		
	echo ""
}

#9.2.19 Check for Presence of User .netrc Files (Scored)
CIS199()
{
	logMsg="9.2.19 Check for Presence of User .netrc Files (Scored)"
	echo $logMsg: $executed
	
	for dir in `/bin/cat /etc/passwd |\ /bin/awk -F: '{ print $6 }'`; do 
	if [ ! -h "$dir/.netrc" -a -f "$dir/.netrc" ]; then 
		echo ".netrc file $dir/.netrc exists" 
	fi 
	done

	echo ""
}

#9.2.20 Check for Presence of User .forward Files (Scored)
CIS200()
{
	logMsg="9.2.20 Check for Presence of User .forward Files (Scored)"
	echo $logMsg: $executed
	
	for dir in `/bin/cat /etc/passwd |\ /bin/awk -F: '{ print $6 }'`; do 
	if [ ! -h "$dir/.forward" -a -f "$dir/.forward" ]; then 
		echo ".forward file $dir/.forward exists" 
	fi 
	done

	echo ""	
}

CIS1
CIS2
CIS3
CIS4
CIS5
CIS6
CIS7
CIS8
CIS9
CIS10
CIS11
CIS12
CIS13
CIS14
CIS15
CIS16
CIS17
CIS18
CIS19
CIS20
CIS21
CIS22
CIS23
CIS24
CIS25
CIS26
CIS27
CIS28
CIS29
CIS30
CIS31
CIS32
CIS33
CIS34
CIS35
CIS36
CIS37
CIS38
CIS39
CIS40
CIS41
CIS42
CIS43
CIS44
CIS45
CIS46
CIS47
CIS48
CIS49
CIS50
CIS51
CIS52
CIS53
CIS54
CIS55
CIS56
CIS57
CIS58
CIS59
CIS60
CIS61
CIS62
CIS63
CIS64
CIS65
CIS66
CIS67
CIS68
CIS69
CIS70
CIS71
CIS72
CIS73
CIS74
CIS75
CIS76
CIS77
CIS78
CIS79
CIS80
CIS81
CIS82
CIS83
CIS84
CIS85
CIS86
CIS87
CIS88
CIS89
CIS90
CIS91
CIS92
CIS93
CIS94
CIS95
CIS96
CIS97
CIS98
CIS99
CIS100
CIS101
CIS102
CIS103
CIS104
CIS105
CIS106
CIS107
CIS108
CIS109
CIS110
CIS111
CIS112
CIS112_
CIS113
CIS114
CIS115
CIS116
CIS117
CIS118
CIS119
CIS120
CIS121
CIS122
CIS123
CIS124
CIS125
CIS126
CIS127
CIS128
CIS129
CIS130
CIS131
CIS132
CIS133
CIS134
CIS135
CIS136
CIS137
CIS138
CIS139
CIS140
CIS141
CIS142
CIS143
CIS144
CIS145
CIS146
CIS147
CIS148
CIS149
CIS150
CIS151
CIS152
CIS153
CIS154
CIS155
CIS156
CIS157
CIS158
CIS159
CIS160
CIS161
CIS162
CIS163
CIS164
CIS165
CIS166
CIS167
CIS168
CIS169
CIS170
CIS171
CIS172
CIS173
CIS174
CIS175
CIS176
CIS177
CIS178
CIS179
CIS180
CIS181
CIS182
CIS183
CIS184
CIS185
CIS186
CIS187
CIS188
CIS189
CIS190
CIS191
CIS192
CIS193
CIS194

########
#CIS195
#CIS196
#CIS197
#CIS198
#CIS199
#CIS200

echo "Done!"